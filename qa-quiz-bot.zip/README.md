# QA Quiz Bot (Telegram, aiogram v3)

A simple Telegram quiz bot for QA beginners and students. Built with **aiogram v3** and designed for 50+ randomized questions, scoring, and explanations.

## ✨ Features
- Randomized quiz with up to 50 unique questions per session
- Inline keyboard answers (A–D) with instant feedback
- Explanations for each answer
- Final score summary

## 🧰 Tech Stack
- Python 3.11+
- [aiogram v3](https://docs.aiogram.dev/en/dev-3.x/)

## 🚀 Quickstart

1) **Clone & enter the repo**
```bash
git clone https://github.com/your-username/qa-quiz-bot.git
cd qa-quiz-bot
```

2) **Create virtual env & install deps**
```bash
python -m venv .venv
# Windows PowerShell
. .venv/Scripts/Activate.ps1
# macOS/Linux
# source .venv/bin/activate

pip install -r requirements.txt
```

3) **Configure environment**
- Create a bot with @BotFather and get the token
- Copy `.env.example` to `.env` and paste your token

```bash
cp .env.example .env  # macOS/Linux
# Windows:
# copy .env.example .env
```

4) **Run the bot**
```bash
python main.py
```

## 🔐 Security note
Never hardcode your Telegram token in the source code or commit `.env`.  
This repo uses an environment variable: `TELEGRAM_BOT_TOKEN`.

## 🧪 Questions bank
Edit `questions.py` to add/modify your questions.

## 📂 Project structure
```
qa-quiz-bot/
├─ main.py              # Entry point (loads token from .env)
├─ questions.py         # QA questions data
├─ requirements.txt
├─ .env.example
├─ .gitignore
├─ LICENSE
├─ SECURITY.md
├─ CONTRIBUTING.md
└─ README.md
```

## 📄 License
MIT © 2025 Oleh Sytnyk
