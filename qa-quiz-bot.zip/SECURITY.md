# Security Policy

## Supported Versions
We support the `main` branch.

## Reporting a Vulnerability
Please **do not** open public issues for security problems.
Email the maintainer privately or use GitHub Security Advisories.
