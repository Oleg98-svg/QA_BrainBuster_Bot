import asyncio
import os
from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from dotenv import load_dotenv
from questions import ALL_QUESTIONS
import random

load_dotenv()
API_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
if not API_TOKEN:
    raise RuntimeError("TELEGRAM_BOT_TOKEN is not set. Create .env from .env.example")

bot = Bot(token=API_TOKEN)
dp = Dispatcher()

user_data = {}

def get_keyboard(options):
    keyboard = [[KeyboardButton(text=chr(65 + i))] for i in range(len(options))]
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)

@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    user_id = message.from_user.id
    questions_copy = random.sample(ALL_QUESTIONS, k=min(50, len(ALL_QUESTIONS)))
    user_data[user_id] = {
        "score": 0,
        "total": 0,
        "questions": questions_copy,
        "current": None
    }
    await send_question(message)

async def send_question(message: types.Message):
    user_id = message.from_user.id
    data = user_data[user_id]

    if not data["questions"]:
        percent = round(data["score"] / data["total"] * 100) if data["total"] > 0 else 0
        await message.answer(
            f"🏁 Квіз завершено!\n"
            f"✅ Ви відповіли правильно на {data['score']} з {data['total']}.\n"
            f"🎯 Точність: {percent}%\n\nНатисніть /start щоб почати знову.",
            reply_markup=types.ReplyKeyboardRemove()
        )
        return

    question = data["questions"].pop(0)
    data["current"] = question

    text = f"🧠 *Питання {data['total'] + 1}/50:*\n{question['question']}\n\n"
    for i, opt in enumerate(question["options"]):
        text += f"{chr(65 + i)}) {opt}\n"

    keyboard = get_keyboard(question["options"])
    await message.answer(text, reply_markup=keyboard, parse_mode="Markdown")


@dp.message(F.text.in_({"A", "B", "C", "D"}))
async def handle_answer(message: types.Message):
    user_id = message.from_user.id
    data = user_data.get(user_id)

    if not data or not data.get("current"):
        await message.answer("Натисніть /start щоб почати спочатку.")
        return

    user_answer = message.text.strip().upper()
    question = data["current"]
    correct_letter = chr(65 + question["answer"])

    data["total"] += 1
    if user_answer == correct_letter:
        data["score"] += 1
        response = "✅ Правильно!"
    else:
        correct_text = question["options"][question["answer"]]
        response = f"❌ Неправильно! Правильна відповідь: {correct_letter}) {correct_text}"

    response += f"\n💡 {question['explanation']}"
    response += f"\n\n🎯 Рахунок: {data['score']}/{data['total']}"
    await message.answer(response)

    await send_question(message)


async def main():
    print("🤖 Бот запущений!")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
