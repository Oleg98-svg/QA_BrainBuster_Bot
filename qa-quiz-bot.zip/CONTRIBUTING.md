# Contributing

1. Fork the repo and create your branch from `main`.
2. Use Python 3.11+ and `aiogram v3`.
3. Run and test locally.
4. Submit a PR with a clear description.
